﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Який факторіал рахуємо: ");
        int n = Convert.ToInt32(Console.ReadLine());
        long factorial = 1;
        Console.Write($"!{n} = ");
        for (int i = 2; i <= n; i++)
        {
            factorial *= i;
            Console.Write($"{i} * ");
        }

        Console.WriteLine($"Факторіал {n} = {factorial}");
    }
}
