﻿using Microsoft.AspNetCore.Mvc;

namespace lr_2.Controllers
{
    public class ResolveController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
